import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home {
//
  prompt: string = '';
  isSubmitting = false;

  submitPrompt(): void {
    const text = this.prompt.trim();
    if (!text || this.isSubmitting) return;

    this.isSubmitting = true;

    // TODO: replace this with your actual submit logic/service call
    // Simulate async action
    setTimeout(() => {
      console.log('Submitted prompt:', text);
      // Optionally clear after submission:
      // this.prompt = '';
      this.isSubmitting = false;
    }, 600);
  }

  clearPrompt(): void {
    if (this.isSubmitting) return;
    this.prompt = '';
  }
  get isSubmitDisabled(): boolean {
  return !((this.prompt ?? '').trim()) || this.isSubmitting;

}
}

